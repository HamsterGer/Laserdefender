using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class Player : MonoBehaviour
{
    [SerializeField] float moveSpeed = 5f;

    [SerializeField] float paddingLeft;
    [SerializeField] float paddingRight;
    [SerializeField] float paddingTop;
    [SerializeField] float paddingBottom;

    Vector2 rawInput;
    Vector2 minBounds;
    Vector2 maxBounds;

    /**Code From the old laser Defender tutorial
    float xMin;
    float xMax;
    float yMin;
    float yMax;
    **/

    void Stat()
    {
        InitBounds();
    }

    void Update()
    {
        Move();
    }

    void InitBounds()
    {
        Camera mainCamera = Camera.main;
        minBounds = mainCamera.ViewportToWorldPoint(new Vector2(0,0));
        maxBounds = mainCamera.ViewportToWorldPoint(new Vector2(1,1));

        /**Code From the old laser Defender tutorial
        xMin = mainCamera.ViewportToWorldPoint(new Vector3(0, 0,0)).x;
        xMax = mainCamera.ViewportToWorldPoint(new Vector3(1, 0,0)).x;
        yMin = mainCamera.ViewportToWorldPoint(new Vector3(0, 0, 0)).y;
        yMax = mainCamera.ViewportToWorldPoint(new Vector3(0, 1, 0)).y;
        **/

    }

    void Move()
    {
        //MoveSpeed is 10 also in the inspektor
        //Debug.Log("MOVE VALUES");
        //Debug.Log("rawInput: " + rawInput);
        //Debug.Log("moveSpeed: " + moveSpeed);
        //Debug.Log("Time.deltaTime: " + Time.deltaTime);
        
        float newSpeed = 10f;

        Vector2 delta = rawInput * newSpeed * Time.deltaTime;  //10f for moveSpeed dosen't work
        Vector2 newPos = new Vector2();
        newPos.x = Mathf.Clamp(transform.position.x + delta.x, minBounds.x, maxBounds.x);
        newPos.y = Mathf.Clamp(transform.position.y + delta.y, minBounds.y, maxBounds.y);
        //With padding
        //newPos.x = Mathf.Clamp(transform.position.x + delta.x, minBounds.x + paddingLeft, maxBounds.x - paddingRight);
        //newPos.y = Mathf.Clamp(transform.position.y + delta.y, minBounds.y + paddingBottom, maxBounds.y - paddingTop);

        transform.position = newPos;

        //Debug.Log("newPosx" + newPos.x);
        //Debug.Log("newPosy" + newPos.y);
        //Debug.Log("Delta " + delta);
        //Debug.Log("newPos" + newPos);


        /**Code From the old laser Defender tutorial -->was a Try, but user inputs dosen't work
        //var deltaX = Input.GetAxis("Horizontal") * Time.deltaTime * moveSpeed;
        //var deltaY = Input.GetAxis("Vertical") * Time.deltaTime * moveSpeed;

        //var newXPos = Mathf.Clamp(transform.position.x + delta.x, xMin, xMax);
        //var newYPos = Mathf.Clamp(transform.position.y + delta.y, yMin, yMax);
        //transform.position = new Vector2(newXPos, newYPos);
        **/

    }

    void OnMove(InputValue value)
    {
        rawInput = value.Get<Vector2>();
        Debug.Log(rawInput);
    }
}
